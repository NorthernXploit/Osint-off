from flask import Flask, render_template, request
import requests
from bs4 import BeautifulSoup
import re

app = Flask(__name__)

# Function to perform web scraping based on the search query
def scrape_data(query):
    search_url = f"https://www.google.com/search?q={query}"
    headers = {"User-Agent": "Mozilla/5.0"}
    response = requests.get(search_url, headers=headers)

    # Parse the search results
    soup = BeautifulSoup(response.text, 'html.parser')
    results = []

    # Extracting titles, URLs, and images
    for item in soup.find_all('a', href=True):
        link = item['href']
        if "/url?q=" in link:  # Only extract actual URLs from Google's search results
            clean_link = link.split("/url?q=")[1].split("&")[0]  # Clean the URL
            title = item.get_text()
            
            # Attempt to find an image nearby the search result
            image_tag = item.find('img')
            image_url = image_tag['src'] if image_tag else None  # Extract the image source

            if title:
                results.append({
                    'title': title,
                    'link': clean_link,
                    'image': image_url  # Add image URL if available
                })

    return results

# Function to evaluate a basic threat model
def threat_model(results):
    threat = "Low"
    sensitive_data_found = False

    # Simple rules to categorize threat level based on found data
    for result in results:
        if re.search(r'\b\d{10,11}\b', result['title']):  # Check for phone numbers
            sensitive_data_found = True
        if re.search(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b', result['title']):  # Check for emails
            sensitive_data_found = True

    if sensitive_data_found:
        threat = "High"
    
    return threat

# Route for the homepage
@app.route('/')
def home():
    return render_template('index.html')

# Route to handle the search and display results
@app.route('/search', methods=['POST'])
def search():
    query = request.form.get('query')
    results = scrape_data(query)
    threat = threat_model(results)
    return render_template('results.html', query=query, results=results, threat=threat)

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=8080)
    