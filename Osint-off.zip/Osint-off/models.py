from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)  # Hash this in production
    is_premium = db.Column(db.Boolean, default=False)
    search_count = db.Column(db.Integer, default=0)  # Track the number of searches

    def __repr__(self):
        return f'<User {self.username}>'
